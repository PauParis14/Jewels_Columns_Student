﻿using System;
using System.Threading.Tasks;

namespace Jewels_Columns_Student
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
